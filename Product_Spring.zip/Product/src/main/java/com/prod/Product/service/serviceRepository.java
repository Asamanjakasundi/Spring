package com.prod.Product.service;

import com.prod.Product.entity.Product;

public class serviceRepository {
	
	Product repository;
	

}
